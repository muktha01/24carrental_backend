# 🚀 cPanel Deployment Guide - 24 Car Rental Backend

## 📦 Package Contents

This deployment package includes:
- ✅ Backend code (models, routes, lib, scripts)
- ✅ Updated middleware.js for production authentication
- ✅ .env.production template (MUST BE CONFIGURED)
- ✅ .htaccess for reverse proxy setup
- ✅ package.json with all dependencies

## 🔧 Pre-Deployment Checklist

### 1. Configure Environment Variables

**CRITICAL:** Before deploying, update `.env.production` with your actual values:

```env
JWT_SECRET=CHANGE_THIS_TO_A_STRONG_RANDOM_SECRET_KEY
MONGODB_URI=your-actual-mongodb-connection-string
CLOUDINARY_CLOUD_NAME=your-cloud-name
CLOUDINARY_API_KEY=your-api-key
CLOUDINARY_API_SECRET=your-api-secret
FIREBASE_SERVICE_ACCOUNT_JSON={"type":"service_account",...}
ZWITCH_API_KEY=your-key
ZWITCH_API_SECRET=your-secret
ALLOWED_ORIGINS=https://udriveadmin.site
```

### 2. MongoDB Setup

- **Option A:** Use MongoDB Atlas (Recommended)
  - Create cluster at https://cloud.mongodb.com
  - Whitelist cPanel server IP
  - Create database user
  - Copy connection string

- **Option B:** Use cPanel MongoDB
  - Create database in cPanel
  - Create database user
  - Use: `mongodb://localhost:27017/24carrental`

## 📤 Deployment Steps

### Step 1: Upload to cPanel

1. **Login to cPanel** at https://sh.spacewelt.com/cpanel
2. **Open File Manager**
3. **Navigate to** `/home/udrivead/`
4. **Create folder** named `backend`
5. **Navigate to** `/home/udrivead/backend/`
6. **Upload** `backend-production.zip`
7. **Right-click** → **Extract**
8. **Delete** the zip file after extraction

### Step 2: Setup Node.js Application

1. **Go to:** Software → Setup Node.js App
2. **Click:** Create Application
3. **Configure:**
   ```
   Node.js version: 18.20.5 (or highest available)
   Application mode: Production
   Application root: /home/udrivead/backend
   Application URL: udriveadmin.site
   Application startup file: server.js
   ```

4. **Add Environment Variables** (from .env.production):
   - Click "+ ADD VARIABLE" for each variable
   - Copy all values from `.env.production`
   - **IMPORTANT:** Use your actual production values!

5. **Click:** CREATE

### Step 3: Install Dependencies

1. **Open Terminal** in cPanel (Advanced → Terminal)
2. **Run commands:**
   ```bash
   cd /home/udrivead/backend
   npm install --production
   ```

### Step 4: Configure Reverse Proxy

1. **Navigate to** `/home/udrivead/public_html/` in File Manager
2. **Copy** `.htaccess` from backend folder to `public_html/`
3. **OR create new** `.htaccess` with proxy rules (already included)

### Step 5: Start Application

1. **Go back to:** Setup Node.js App
2. **Find your application**
3. **Click:** START
4. **Check status:** Should show "Running"

## ✅ Verify Deployment

Test these URLs in your browser:

```
✅ https://udriveadmin.site/
   Expected: {"status":"24 Car Rental backend","version":"0.1.0","environment":"production"}

✅ https://udriveadmin.site/health
   Expected: {"status":"healthy","timestamp":"..."}

✅ https://udriveadmin.site/api/cities
   Expected: Your API data or authentication error (normal without token)
```

## 🔍 Troubleshooting

### Application Won't Start

**Check Node.js App logs:**
- Go to: Setup Node.js App → Your app → View logs
- Look for errors (missing env vars, MongoDB connection issues)

**Common issues:**
- ❌ Missing environment variables → Add in Node.js interface
- ❌ MongoDB connection failed → Check MONGODB_URI and whitelist IP
- ❌ Port already in use → Change PORT in environment variables
- ❌ Permission denied → Check file permissions (644 for files, 755 for directories)

### Fix File Permissions

In Terminal:
```bash
cd /home/udrivead/backend
find . -type f -exec chmod 644 {} \;
find . -type d -exec chmod 755 {} \;
chmod 755 server.js
```

### View Logs

```bash
# Application logs
tail -f /home/udrivead/logs/nodejs.log

# Error logs
tail -f /home/udrivead/logs/error_log
```

### Restart Application

After any configuration changes:
1. Go to: Setup Node.js App
2. Click: RESTART
3. Wait for status: "Running"

## 🔒 Security Checklist

- ✅ Change JWT_SECRET from default
- ✅ Use strong passwords for MongoDB
- ✅ Enable SSL/HTTPS for domain
- ✅ Whitelist only your IPs in MongoDB
- ✅ Keep dependencies updated
- ✅ Never commit .env files to git

## 📞 Support

If you encounter issues:

1. **Check logs** in Node.js App interface
2. **Verify environment variables** are set correctly
3. **Test MongoDB connection** separately
4. **Check cPanel error logs** in Metrics → Errors

## 🔄 Updating After Deployment

To update the backend:

1. **Stop application** in Node.js interface
2. **Upload new files** via File Manager
3. **Run:** `npm install --production`
4. **Restart application**

## 📋 Quick Reference

**Server Paths:**
- Backend: `/home/udrivead/backend/`
- Public: `/home/udrivead/public_html/`
- Logs: `/home/udrivead/logs/`

**Important Files:**
- Startup: `server.js`
- Config: Environment variables in Node.js interface
- Database: `db.js`
- Middleware: `routes/middleware.js`

**Terminal Commands:**
```bash
# Navigate to backend
cd /home/udrivead/backend

# Install dependencies
npm install --production

# Check Node version
node --version

# View logs
tail -f ~/logs/nodejs.log
```

---

✨ **Your backend is now deployed on cPanel!**
