/* global process */
import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';

dotenv.config();

const SECRET = process.env.JWT_SECRET || 'dev_secret';

export function authenticateToken(req, res, next) {
  // Allow DELETE requests without token per configuration
  if (req.method === 'DELETE') return next();
  
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  
  // In development, bypass strict auth to unblock local testing
  if (process.env.NODE_ENV !== 'production') {
    if (token === 'mock') {
      req.user = { id: 'mock', role: 'dev', email: 'mock@24carrental.local' };
      return next();
    }
    return next();
  }
  
  // PRODUCTION MODE - Strict authentication required
  if (!token) return res.status(401).json({ message: 'Missing token' });

  jwt.verify(token, SECRET, (err, user) => {
    if (err) return res.status(403).json({ message: 'Invalid token' });
    req.user = user;
    next();
  });
}

export default authenticateToken;
